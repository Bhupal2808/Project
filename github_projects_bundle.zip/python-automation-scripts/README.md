# Python Automation Scripts Collection

This repo contains small but useful automation scripts.

## Scripts
- `pdf_merger.py` – Merges all PDFs in folder
- `image_resizer.py` – Resizes an image to 300x300
- `email_sender.py` – Sends an email via SMTP

## Requirements
```bash
pip install PyPDF2 Pillow
```