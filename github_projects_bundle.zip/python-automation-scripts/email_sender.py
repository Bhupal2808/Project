import smtplib
from email.message import EmailMessage

msg = EmailMessage()
msg['Subject'] = 'Test Mail'
msg['From'] = 'you@example.com'
msg['To'] = 'target@example.com'
msg.set_content('This is a test email from Python script.')

with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
    smtp.login('you@example.com', 'yourpassword')
    smtp.send_message(msg)