from PIL import Image

img = Image.open('image.jpg')
img = img.resize((300, 300))
img.save('resized_image.jpg')