# AI Chatbot using Python

This is a simple AI chatbot built with Python, PyTorch, and NLP. It uses a basic neural network to classify user intent and respond accordingly.

## Features
- Intent classification
- Pattern-response matching
- Trained on custom `intents.json`

## Setup
```bash
pip install torch nltk
python train.py
python chat.py
```