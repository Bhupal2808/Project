import json
import torch
import torch.nn as nn
from nltk_utils import tokenize, stem, bag_of_words
from model import NeuralNet

with open('intents.json', 'r') as f:
    intents = json.load(f)

all_words, tags, xy = [], [], []
for intent in intents['intents']:
    tag = intent['tag']
    tags.append(tag)
    for pattern in intent['patterns']:
        w = tokenize(pattern)
        all_words.extend(w)
        xy.append((w, tag))

ignore_words = ['?', '.', '!']
all_words = sorted(set([stem(w) for w in all_words if w not in ignore_words]))
tags = sorted(set(tags))

X_train, y_train = [], []
for (pattern_sentence, tag) in xy:
    bag = bag_of_words(pattern_sentence, all_words)
    X_train.append(bag)
    y_train.append(tags.index(tag))

X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train)

model = NeuralNet(len(all_words), 8, len(tags))
loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

for epoch in range(1000):
    out = model(X_train)
    loss = loss_fn(out, y_train)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

torch.save({'model_state': model.state_dict(), 'input_size': len(all_words),
            'hidden_size': 8, 'output_size': len(tags),
            'all_words': all_words, 'tags': tags}, 'model.pth')