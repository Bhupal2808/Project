import torch
import random
from model import NeuralNet
from nltk_utils import bag_of_words, tokenize

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
data = torch.load('model.pth')

model = NeuralNet(data['input_size'], 8, data['output_size']).to(device)
model.load_state_dict(data['model_state'])
model.eval()

all_words = data['all_words']
tags = data['tags']

with open('intents.json', 'r') as f:
    intents = json.load(f)

print("Chatbot is ready! Type 'quit' to exit.")
while True:
    sentence = input("You: ")
    if sentence == "quit":
        break
    sentence = tokenize(sentence)
    X = bag_of_words(sentence, all_words)
    X = torch.tensor(X, dtype=torch.float32).to(device)
    output = model(X)
    _, predicted = torch.max(output, dim=0)
    tag = tags[predicted.item()]
    for intent in intents['intents']:
        if intent['tag'] == tag:
            print(f"Bot: {random.choice(intent['responses'])}")