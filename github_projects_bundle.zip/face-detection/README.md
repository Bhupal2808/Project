# Face Detection App

A real-time face detection app using OpenCV and Haar Cascades.

## Features
- Detect faces via webcam
- Draw bounding box around faces
- Lightweight and fast

## Usage
```bash
pip install opencv-python
python main.py
```

## Note
Download `haarcascade_frontalface_default.xml` from OpenCV GitHub if not present.